<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .element {
        display: inline-block;
        width: 100%;
        height: 100vh;
        border: none;
    }


    .flexLayout {
        display: flex;
    }
    </style>
</head>


<body>
    <div class="flexLayout">
        <iframe src="/PBL4/filePHP/user/thongtinuser/thongtinuser.php" class="element"></iframe>
        <iframe src="/PBL4/filePHP/user/thongtinuser/thongtincar.php" class="element"></iframe>
    </div>
</body>

</html>